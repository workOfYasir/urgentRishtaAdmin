<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WorkoutPlanNote extends Model
{
    protected $fillable=['week_id','notes'];
}
